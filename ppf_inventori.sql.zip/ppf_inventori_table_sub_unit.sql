
-- --------------------------------------------------------

--
-- Table structure for table `sub_unit`
--

CREATE TABLE `sub_unit` (
  `id` int(11) NOT NULL,
  `sub_unit` text NOT NULL,
  `kd_sub_unit` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_unit`
--

INSERT INTO `sub_unit` (`id`, `sub_unit`, `kd_sub_unit`) VALUES
(1, 'Teknisi', '01'),
(2, 'K3L', '02'),
(3, 'Sarana Prasarana', '03'),
(4, 'Teknologi Informasi', '04'),
(5, 'Keamanan', '05'),
(6, 'Lingkungan', '06');
