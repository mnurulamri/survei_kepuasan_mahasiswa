
-- --------------------------------------------------------

--
-- Table structure for table `survei_pertanyaan_terbuka`
--

CREATE TABLE `survei_pertanyaan_terbuka` (
  `id` int(11) NOT NULL,
  `pertanyaan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survei_pertanyaan_terbuka`
--

INSERT INTO `survei_pertanyaan_terbuka` (`id`, `pertanyaan`) VALUES
(1, 'Apa yang Anda sukai dari layanan sarana/prasarana ini?'),
(2, 'Apa yang perlu diperbaiki?'),
(3, 'Saran Anda untuk meningkatkan kualitas layanan?');
