
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `hak_akses` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `nama`, `unit`, `email`, `hak_akses`) VALUES
(1, 'mnurulamri', '', NULL, 'OPF', '', 1),
(2, 'adnan', '', NULL, 'OPF', '', 1),
(3, 'purwono', '', NULL, 'OPF', '', 1),
(4, 'abdulasman', '', NULL, 'OPF', '', 2),
(5, 'fajaruddin.widodo', '', NULL, 'OPF', '', 2),
(6, 'das60', '', NULL, 'OPF', '', 1),
(7, 'slamet71', '', NULL, 'OPF', '', 2),
(8, 'adeseptian', '', NULL, 'OPF', '', 2),
(9, 'amud', '', NULL, 'OPF', '', 2),
(10, 'e.atmaja', '', NULL, 'OPF', '', 2),
(11, 'herdiansyah', '', NULL, 'OPF', '', 2),
(12, 'jaanih', '', NULL, 'OPF', '', 2),
(13, 'jaya.miharja', '', NULL, 'OPF', '', 2),
(14, 'jemadi', '', NULL, 'OPF', '', 2),
(15, 'm.kusno', '', NULL, 'OPF', '', 2),
(16, 'mulyadi71', '', NULL, 'OPF', '', 2),
(17, 'narwan', '', NULL, 'OPF', '', 2),
(18, 'nurpai', '', NULL, 'OPF', '', 2),
(19, 'robbysaputra', '', NULL, 'OPF', '', 2),
(20, 'saniman', '', NULL, 'OPF', '', 2),
(21, 'saryouse', '', NULL, 'OPF', '', 2),
(22, 'somad', '', NULL, 'OPF', '', 2),
(23, 'sulaeman62', '', NULL, 'OPF', '', 2),
(24, 'supriatna', '', NULL, 'OPF', '', 2),
(25, 'yofri.s', '', NULL, 'OPF', '', 2),
(26, 'ricky.haryanto09', '', 'Ricky Haryanto Sutjipto, S.H.', 'OPF', 'rickyhs2009@gmail.com', 1);
