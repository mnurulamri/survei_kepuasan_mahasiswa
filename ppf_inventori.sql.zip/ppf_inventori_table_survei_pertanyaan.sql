
-- --------------------------------------------------------

--
-- Table structure for table `survei_pertanyaan`
--

CREATE TABLE `survei_pertanyaan` (
  `id` int(11) NOT NULL,
  `kategori_id` int(11) DEFAULT NULL,
  `pertanyaan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survei_pertanyaan`
--

INSERT INTO `survei_pertanyaan` (`id`, `kategori_id`, `pertanyaan`) VALUES
(1, 1, 'Seberapa puas Anda dengan kualitas layanan yang diberikan?'),
(2, 1, 'Apakah Anda merasa nyaman saat menggunakan sarana/prasarana ini?'),
(3, 1, 'Seberapa mudahkah Anda mengakses informasi tentang sarana/prasarana ini?'),
(4, 2, 'Seberapa puas Anda dengan kebersihan sarana?'),
(5, 2, 'Apakah sarana tersebut selalu tersedia saat dibutuhkan?'),
(6, 2, 'Seberapa baik kualitas fasilitas penunjang (AC, Wi-Fi, dll.)?'),
(7, 2, 'Apakah petugas sarana ramah dan membantu?'),
(8, 3, 'Seberapa puas Anda dengan kondisi jalan/infrastruktur?'),
(9, 3, 'Apakah prasarana tersebut aman dari kerusakan?'),
(10, 3, 'Seberapa baik kualitas pencahayaan dan keamanan?'),
(11, 3, 'Apakah prasarana tersebut mudah diakses oleh disabilitas?'),
(12, 4, 'Seberapa puas Anda dengan responsivitas petugas?'),
(13, 4, 'Apakah petugas membantu dan ramah?'),
(14, 4, 'Seberapa mudahkah Anda melaporkan keluhan atau saran?'),
(15, 4, 'Apakah ada perbaikan signifikan dalam layanan sarana/prasarana ini?');
