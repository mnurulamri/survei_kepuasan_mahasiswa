
-- --------------------------------------------------------

--
-- Table structure for table `survei_kategori`
--

CREATE TABLE `survei_kategori` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survei_kategori`
--

INSERT INTO `survei_kategori` (`id`, `nama_kategori`) VALUES
(1, 'Umum'),
(2, 'Sarana'),
(3, 'Prasarana'),
(4, 'Pelayanan'),
(5, 'testing');
