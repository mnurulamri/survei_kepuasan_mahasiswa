
-- --------------------------------------------------------

--
-- Table structure for table `survei`
--

CREATE TABLE `survei` (
  `id` int(11) NOT NULL,
  `survei_id` varchar(10) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jenis` int(11) DEFAULT NULL,
  `komentar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `periode` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survei`
--

INSERT INTO `survei` (`id`, `survei_id`, `username`, `nama`, `unit`, `email`, `jenis`, `komentar`, `created_at`, `periode`) VALUES
(1, '1739934874', 'mnurulamri', 'xx', 'Unit', '', 0, NULL, '2025-02-19 03:14:34', NULL),
(2, '1739934988', 'mnurulamri', 'xx', 'Unit', '', 0, NULL, '2025-02-19 03:16:28', NULL),
(3, '1739936136', 'mnurulamri', 'xx', 'Unit', '', 0, NULL, '2025-02-19 03:35:36', NULL),
(4, '1739936399', 'mnurulamri', 'xx', 'Unit', '', 0, NULL, '2025-02-19 03:39:59', NULL),
(5, '1739936455', 'mnurulamri', 'xx', 'Unit', '', 0, NULL, '2025-02-19 03:40:55', NULL),
(6, '1739936864', 'mnurulamri', 'xx', 'Unit', '', 0, NULL, '2025-02-19 03:47:44', NULL);
