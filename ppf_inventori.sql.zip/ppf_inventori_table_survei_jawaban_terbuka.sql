
-- --------------------------------------------------------

--
-- Table structure for table `survei_jawaban_terbuka`
--

CREATE TABLE `survei_jawaban_terbuka` (
  `id` int(11) NOT NULL,
  `survei_id` varchar(10) DEFAULT NULL,
  `pertanyaan_terbuka_id` int(11) DEFAULT NULL,
  `jawaban` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survei_jawaban_terbuka`
--

INSERT INTO `survei_jawaban_terbuka` (`id`, `survei_id`, `pertanyaan_terbuka_id`, `jawaban`) VALUES
(1, '1739936399', 1, 'xx'),
(3, '1739936013', 3, 'xx'),
(4, '1739936455', 1, 'xx'),
(6, '1739936599', 1, 'xx'),
(8, '1739936647', 1, 'xx'),
(10, '1739936647', 1, 'xx'),
(11, '1739936647', 2, 'xx'),
(12, '1739936647', 3, 'xx'),
(13, '1739936864', 1, 'x'),
(14, '1739936864', 2, 'x'),
(15, '1739936864', 3, 'x');
